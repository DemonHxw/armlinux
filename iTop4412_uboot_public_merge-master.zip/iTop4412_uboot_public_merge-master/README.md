# iTop4412_uboot_public_merge
Merge all kinds of uboot version to only one

Build Method:

first "cd iTop4412_uboot" source path:


1 CPU:SCP DDR:1G CoreBoard:

linux or android OS

  #./build_uboot.sh SCP_1GDDR

  # make

Ubuntu for ARM

  #./build_uboot.sh SCP_1GDDR_Ubuntu

  # make
   
2  CPU:SCP DDR:2G CoreBoard:

linux or android OS

  #./build_uboot.sh SCP_2GDDR

  # make

Ubuntu for ARM

  #./build_uboot.sh SCP_2GDDR_Ubuntu

  # make
  
3 CPU:POP DDR:1G CoreBoard:

linux or android OS

  #./build_uboot.sh POP_1GDDR

  # make

Ubuntu for ARM

  #./build_uboot.sh POP_1GDDR_Ubuntu

  # make
  
4 CPU:POP DDR:2G CoreBoard:

linux or android OS

  #./build_uboot.sh POP_2GDDR

  # make

Ubuntu for ARM

  #./build_uboot.sh POP_2GDDR_Ubuntu

  # make
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
