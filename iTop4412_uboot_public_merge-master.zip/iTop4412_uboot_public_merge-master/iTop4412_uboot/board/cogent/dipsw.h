extern unsigned char dipsw_raw(void);
extern unsigned char dipsw_cooked(void);
extern void dipsw_init(void);
